$(document).ready(function(){

//when search button is clicked, the api is called and collects required info
	$("#get").on('click',function(event){
		var movie = document.getElementById('name1').value;
      var title = "Title"; //gets title value
      var genre = "Genre"; //gets genre value
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=" + movie + "&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src='+json[poster]+'>' +'<h4 id="load">This is the rating for '+movie+'</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards for the movie</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');
        });
	}); 

//shows information for the top 5 movies on the page
$(".topmovies1").on('click',function(event){

      var title = "Title"; //gets title field
      var genre = "Genre"; //gets genre type
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=moana&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src= "/images/movie1.jpg">' +'<h4 id="load">This is the rating for Moana</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');
        });

  });  
$(".topmovies2").on('click',function(event){

      var title = "Title"; //gets title field
      var genre = "Genre"; //gets genre type
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=the+girl+on+the+train&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src= "/images/movie2.jpg">' +'<h4 id="load">This is the rating for Moana</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');

  });
  });
$(".topmovies3").on('click',function(event){

      var title = "Title"; //gets title field
      var genre = "Genre"; //gets genre type
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=sully&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src= "/images/movie3.jpg">' +'<h4 id="load">This is the rating for Moana</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');

  });
  });
$(".topmovies4").on('click',function(event){

      var title = "Title"; //gets title field
      var genre = "Genre"; //gets genre type
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=doctor+strange&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src= "/images/movie4.jpg">' +'<h4 id="load">This is the rating for Moana</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');

  });
  });
$(".topmovies5").on('click',function(event){

      var title = "Title"; //gets title field
      var genre = "Genre"; //gets genre type
      var rating = "imdbRating"; //accesses the imbdRating key's value in the jsonp file 
      var award = "Awards"; //accesses the Awards key's value in the jsonp file
      var poster = "Poster"; //poster value
        $.getJSON("https://www.omdbapi.com/?t=trolls&y=&plot=short&r=jsonp", function(json) { //the first part of the url is standard, then it appends the var movie and the rest of the standard url
                $('#responseArea1').html('<p>Movie poster</p><img src= "/images/movie5.jpg">' +'<h4 id="load">This is the rating for Moana</h4><p>' + json[rating] + '</p>'+ //this adds text to the html after retrieved info from api
                  '<h4 id="load">These are the awards</h4>' + json[award] + '</p>' +
                  '<h4> Genre</h4><p>'+ json[genre]+'</p>');

  });
  });

//when the get past searches button is clicked, GET request sent to show movieCollection array
  $("#getAll").on('click',function(event){
    var movie = document.getElementById('name1').value;
    $("#body").append('<p id="responseArea2">Your past searches include:</p>');
    $.ajax({

      url: '/movie/'+movie,
      type: 'GET',
      success: function(result) {
        $("#responseArea2").html(result);
        for (i = 0;i<result.length;i++){
          $("#responseArea2").append(result[i].movie+'<br>');
        }
        
        console.log("get");
        }   
      });
      event.preventDefault();

  })

//once search button is clicked, name is added to array
	$("#get").on('click',function(event){
		var movie = document.getElementById('name1').value;
		$.ajax({
    	url: '/movie/'+movie,
    	type: 'PUT',
      success: function(result){
        console.log(result.movie+"added movie");
      }
    	});

    	event.preventDefault();
	})
});

