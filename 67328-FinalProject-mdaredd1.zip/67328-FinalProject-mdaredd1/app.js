var express = require("express");
 	app = express();
app.set('view engine', 'ejs');

require('./routes/library.js').init(app);

var morgan = require('morgan');
 
app.use(morgan('combined'));
 
app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
	res.render('index');
})


app.listen(50000);
console.log("Server listening at http://localhost:50000/");

