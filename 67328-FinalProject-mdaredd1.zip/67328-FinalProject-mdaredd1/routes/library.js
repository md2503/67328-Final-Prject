var movies = require('../models/libraries.js');

exports.init = function(app) {
  //paths to store and retieve session data
 app.put("/movie/:movie", addmovie);
 app.get("/movie/:movie", getmovie);
 }
 

addmovie = function(request, response){
  //adds to arrat
	response.send(movies.add(request.params.movie))
}

getmovie = function(request, response) {
  //calls methods to print array contents
	response.send(movies.retrieveAll());
	}

  // include my model for this application
  // var mongoModel = require("../models/libraries.js");

 
  // exports.init = function(app) {
  //   app.get('/', index); // essentially the app welcome page
  //   
  //   app.put('/:collection', doCreate); // CRUD Create
  //   app.get('/:collection', doRetrieve); // CRUD Retrieve
  // }
 
  // index = function(req, res) {
  //   res.render('index', {title: 'MongoDB Test'})
  // };

  // doCreate = function(req, res){
  //   mongoModel.create ( req.params.collection, 
  //                      req.body,
  //                      function(result) {
  //                        // result equal to true means create was successful
  //                        var success = (result ? "Create successful" : "Create unsuccessful");
  //                        // res.render('message', {title: 'Mongo Demo', obj: success});
  //                          console.log("2. Done with callback in dbRoutes create");
  //                      });
  //   console.log("3. Done with doCreate in dbRoutes");
  // }

 
  // doRetrieve = function(req, res){

  //   mongoModel.retrieve(
  //     req.params.collection, 
  //     req.query,
  //    function(modelData) {
  //      if (modelData.length) {
  //         res.render('results',{title: 'Mongo Demo', obj: modelData});
  //       } else {
  //         var message = "No documents with "+JSON.stringify(req.query)+ 
  //                       " in collection "+req.params.collection+" found.";
  //         res.render('message', {title: 'Mongo Demo', obj: message});
  //       }
  //    });
  // }

