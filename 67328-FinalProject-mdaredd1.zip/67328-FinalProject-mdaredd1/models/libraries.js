//array to store movie names of session search
var movies = {
	moviesCollection: [],

	//gets all names
	retrieveAll: function(){
		return this.moviesCollection;
		console.log(moviesCollection+"hi");
	},

	//adds name of movie search
	add: function(movie){
		var newmovie = {
			movie: movie,
		};
		this.moviesCollection.push(newmovie);
		return newmovie;
	},
}


module.exports = movies;


// var mongoClient = require('mongodb').MongoClient;

//   var connection_string = 'mongodb://md67328:mswimmerm@ds159507.mlab.com:59507/manisha67328';
 
//   if(process.env.MLAB_NAMEOFMYDB_PASSWD){
//     connection_string = "mongodb://instructor:"
//                         + process.env.MLAB_NAMEOFMYDB_PASSWD
//                         + "@ds050879.mlab.com:50879/nameofmydb"
//   }
 
//   var mongoDB; 
 
//   mongoClient.connect(connection_string, function(err, db) {
//     if (err) doError(err);
//     mongoDB = db;
//   });

// 	exports.create = function(collection, data, callback){
//     mongoDB.collection("movies").insertOne(data, function(err, status) {   
//         if (err) doError(err);
//         var success = (status.result.n == 1 ? true : false);
//         callback(success);
//       });
 
//   };
   
//   exports.retrieve = function(collection, query, callback) {

//     mongoDB.collection(collection).find(query).toArray(function(err, docs) {
//       if (err) doError(err);
//       // docs are MongoDB documents, returned as an array of JavaScript objects
//       // Use the callback provided by the controller to send back the docs.
//       callback(docs);
//     });
//   }
 
  
//   exports.update = function(collection, filter, update, callback) {
//     mongoDB
//       .collection(collection)     // The collection to update
//       .updateMany(                // Use updateOne to only update 1 document
//         filter,                   // Filter selects which documents to update
//         update,                   // The update operation
//         {upsert:true},            // If document not found, insert one with this update
//                                   // Set upsert false (default) to not do insert
//         function(err, status) {   // Callback upon error or success
//           if (err) doError(err);
//           callback('Modified '+ status.modifiedCount 
//                    +' and added '+ status.upsertedCount+" documents");
//           });
//   }
 

//    exports.delete = function(collection, query, callback) {

//     mongoDB.collection(collection).deleteOne(query);
//   }
 
//   var doError = function(e) {
//           console.error("ERROR: " + e);
//           throw new Error(e);
//       }



